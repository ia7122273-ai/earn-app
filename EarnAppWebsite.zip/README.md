# EarnApp — Official App Website (Static)
This repository contains a simple static website for EarnApp: `index.html`, `privacy.html`, `terms.html`.
Use this site as the "Company/Application Website" when publishing your APK to stores like Aptoide.

## Files
- index.html — Landing page
- privacy.html — Privacy Policy
- terms.html — Terms & Conditions

## Deploy (GitHub Pages)
1. Create a GitHub repo (e.g., `earnapp-website`).
2. Push these files to the repository root (main branch).
3. In repo Settings → Pages, select branch `main` and root `/`.
4. Save — your site will be available at: `https://<username>.github.io/<repo>/`

## Deploy (Netlify)
1. Create a Netlify account (free).
2. Click "Add new site" → "Deploy manually" → drag & drop the site ZIP or folder.
3. Site will be live with a `netlify.app` subdomain. Update DNS if you want a custom domain.

## Notes for Aptoide
- Use the deployed URL (GitHub Pages or Netlify) as the "Application Website" when uploading to Aptoide.
- Make sure privacy policy and terms pages are accessible via direct links.

## Contact
For updates or customization, email: irfan@example.com
